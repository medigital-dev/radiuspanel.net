<?php 

    $navigasi = "";
    $navigasi = "import";
    
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
    <title>Import - RadiusPanel</title>
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
    <link rel="shortcut icon" href="img/logo.png" type="image/x-icon">
</head>
<body>
    <?php include 'navigasi.html' ?>
    
    <form method="post" enctype="multipart/form-data" action="upload_aksi.php">
        <div style="width: 400px; height: 500px; border-radius: 10px; position: absolute; left: 50%; transform: translate(-50%, 0); margin-top: 10px; border: 2px solid darkblue">
            <div align="center" style="width: 100%">
                <div style="width: 100%; background-color: darkblue; color: white; text-align: center; height: 50px; border-radius: 7px 7px 0 0; padding: 14px; font-weight: bold;">
                IMPORT USER
                </div>
            </div>
            <div style="margin: 17px; width: 90%">
                <label>Silahkan pilih file excel:</label>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="inputGroupFileAddon01">Upload</span>
                    </div>
                    <div class="custom-file">
                        <input type="file" class="custom-file-input" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01" name="file" required accept=".xls">
                        <label class="custom-file-label" for="inputGroupFile01">Pilih file</label>
                    </div>
                </div>
                <a href="template.xls">
                    Download template Import
                </a>
                <br><br>
                <a style="color: green;">
                <?php 
                    if(isset($_GET['berhasil'])){
                        echo $_GET['berhasil'];
                        echo " data berhasil di import.";
                    }
                ?>
                </a>
            </div>

            <div style="position: fixed; left: 20px; bottom: 20px">
                <a class="btn btn-warning" href="/" title="Kembali">Kembali</a>
            </div>

            <div align="center" style="position: fixed;right: 20px; bottom: 20px;">
                <input class="btn btn-primary" name="upload" type="submit" value="Import User">
            </div>
        
        </div>
    </form>
    
    <?php include 'footer.html'?>

    <script src="bootstrap/jquery-3.5.1.slim.min.js"></script>
    <script src="bootstrap/popper.min.js"></script>
	<script src="bootstrap/bootstrap.min.js"></script>

</body>
</html>